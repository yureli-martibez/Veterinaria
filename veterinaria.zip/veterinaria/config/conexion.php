<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "inventario";

$conexion = new mysqli($host, $user, $pass,$db);

if (!$conexion) {
    echo 'CONEXION FALLIDA';
}
